package com.toubou91.filedetect.tika.example;

/**
 * Hello world!
 *
 */
public class App {

	public static void main(String[] args) {
		System.out.println("Hello world!");
	}
}